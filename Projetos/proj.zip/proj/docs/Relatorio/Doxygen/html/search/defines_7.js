var searchData=
[
  ['kbcmouse',['KBCMOUSE',['../macros_8h.html#a71c7df19a1486e35a6733da4d77774b5',1,'macros.h']]],
  ['kbd_5firq',['KBD_IRQ',['../macros_8h.html#a5c1072213ce8d8cd43628c4319ae0391',1,'macros.h']]]
];
