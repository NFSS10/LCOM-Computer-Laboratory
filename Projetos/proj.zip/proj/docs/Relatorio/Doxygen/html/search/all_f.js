var searchData=
[
  ['obf',['OBF',['../macros_8h.html#a45967c9e25447ba853cf6fb4ac545fe6',1,'macros.h']]],
  ['oceano',['Oceano',['../_graficos_8c.html#ac59f937c1ecfa86ff20465da839a06f1',1,'Graficos.c']]],
  ['offset',['offset',['../struct_b_m_p___file___header.html#aa414452cfb615ee753a4ced47690a897',1,'BMP_File_Header']]],
  ['out_5fbuf',['OUT_BUF',['../macros_8h.html#acfb42dde389e8ca36ab267002fbf5c6a',1,'macros.h']]]
];
