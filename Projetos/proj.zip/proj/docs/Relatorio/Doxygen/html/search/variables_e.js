var searchData=
[
  ['tamanho',['tamanho',['../struct_b_m_p___file___header.html#a8390486fe00f26583af4c57bc402964c',1,'BMP_File_Header::tamanho()'],['../struct_b_m_p___info___header.html#a8390486fe00f26583af4c57bc402964c',1,'BMP_Info_Header::tamanho()']]],
  ['tamanho_5fheader',['tamanho_header',['../struct_b_m_p___info___header.html#a01241ea7b8a71124612bd441c17bfcc3',1,'BMP_Info_Header']]]
];
