var searchData=
[
  ['apagaimagem',['apagaImagem',['../_b_m_p_8c.html#ad8c97d5a842fbd539f740cba50e9e82c',1,'apagaImagem(Imagem *img):&#160;BMP.c'],['../_b_m_p_8h.html#ad8c97d5a842fbd539f740cba50e9e82c',1,'apagaImagem(Imagem *img):&#160;BMP.c']]],
  ['apagaimagens',['apagaImagens',['../_graficos_8c.html#adb7cada1982f0e8265d8082560098810',1,'apagaImagens():&#160;Graficos.c'],['../_graficos_8h.html#adb7cada1982f0e8265d8082560098810',1,'apagaImagens():&#160;Graficos.c']]],
  ['atualiza_5ffundo',['atualiza_fundo',['../_graficos_8c.html#a5e41a7543e464a79c9e0f1d8fe83a741',1,'atualiza_fundo():&#160;Graficos.c'],['../_graficos_8h.html#a5e41a7543e464a79c9e0f1d8fe83a741',1,'atualiza_fundo():&#160;Graficos.c']]],
  ['atualiza_5ffundo_5fervas',['atualiza_fundo_ervas',['../_graficos_8c.html#a3c9c22c8e93ce4d6bec13939c85bed19',1,'atualiza_fundo_ervas():&#160;Graficos.c'],['../_graficos_8h.html#a3c9c22c8e93ce4d6bec13939c85bed19',1,'atualiza_fundo_ervas():&#160;Graficos.c']]],
  ['aux_5fconfig',['aux_config',['../mouse_8c.html#afd1aa0adf86282efbd61bc328abf04a5',1,'aux_config(long int *packet_info, int *limite, int *index):&#160;mouse.c'],['../mouse_8h.html#afd1aa0adf86282efbd61bc328abf04a5',1,'aux_config(long int *packet_info, int *limite, int *index):&#160;mouse.c']]]
];
