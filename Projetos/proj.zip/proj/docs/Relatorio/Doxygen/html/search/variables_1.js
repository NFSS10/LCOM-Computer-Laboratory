var searchData=
[
  ['banksize',['BankSize',['../struct____attribute____.html#a7e31ea09e6e6755e3a504b9c76b3f545',1,'__attribute__']]],
  ['bits_5fpor_5fpixel',['bits_por_pixel',['../struct_b_m_p___info___header.html#a64df891621326569351ce01db0565254',1,'BMP_Info_Header']]],
  ['bitsperpixel',['BitsPerPixel',['../struct____attribute____.html#a03756ae144fce823087a2a4255bf4bb1',1,'__attribute__']]],
  ['bluefieldposition',['BlueFieldPosition',['../struct____attribute____.html#a4d0396c07a4f07556332fec2b4a6c2bf',1,'__attribute__']]],
  ['bluemasksize',['BlueMaskSize',['../struct____attribute____.html#a84842a6a42e881ce7be87482122bcc4e',1,'__attribute__']]],
  ['bmp_5finfo',['BMP_info',['../struct_imagem.html#a50332a8a9ad9c04e08ca6bec0863fe1c',1,'Imagem']]],
  ['bnknumberofimagepages',['BnkNumberOfImagePages',['../struct____attribute____.html#a33ba903e149724b1bc99b3b8e43a7cbe',1,'__attribute__']]],
  ['bytesperscanline',['BytesPerScanLine',['../struct____attribute____.html#afe40654a51bf4a12a8b376ff3506688e',1,'__attribute__']]]
];
