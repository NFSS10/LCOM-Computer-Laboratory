var searchData=
[
  ['percorrer_5fbarra',['percorrer_barra',['../_graficos_8c.html#ad7aad79f6d687cadf4318131c05c2f9a',1,'percorrer_barra(unsigned int posicao, unsigned int estado, unsigned int cont, unsigned int x_ale, unsigned int plat_ale, unsigned int n_plat_antiga, int Pontos):&#160;Graficos.c'],['../_graficos_8h.html#ad7aad79f6d687cadf4318131c05c2f9a',1,'percorrer_barra(unsigned int posicao, unsigned int estado, unsigned int cont, unsigned int x_ale, unsigned int plat_ale, unsigned int n_plat_antiga, int Pontos):&#160;Graficos.c']]],
  ['printscore',['printScore',['../_graficos_8c.html#a4561416e9a49dbc3356e2a296498c62d',1,'printScore(int score):&#160;Graficos.c'],['../_graficos_8h.html#a4561416e9a49dbc3356e2a296498c62d',1,'printScore(int score):&#160;Graficos.c']]]
];
