var searchData=
[
  ['choosenumber',['chooseNumber',['../_graficos_8c.html#a485eb8efc917ffeecd48cb1fbf6c5889',1,'chooseNumber(int number):&#160;Graficos.c'],['../_graficos_8h.html#a485eb8efc917ffeecd48cb1fbf6c5889',1,'chooseNumber(int number):&#160;Graficos.c']]],
  ['choosenumbergame',['chooseNumberGame',['../_graficos_8c.html#abf8c5da4ee57499763af5592885bc7ce',1,'chooseNumberGame(int number):&#160;Graficos.c'],['../_graficos_8h.html#abf8c5da4ee57499763af5592885bc7ce',1,'chooseNumberGame(int number):&#160;Graficos.c']]],
  ['compressao',['compressao',['../struct_b_m_p___info___header.html#a7400a3653d4286bb61b44c09782e2985',1,'BMP_Info_Header']]]
];
