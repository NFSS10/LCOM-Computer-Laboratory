var searchData=
[
  ['obf',['OBF',['../macros_8h.html#a45967c9e25447ba853cf6fb4ac545fe6',1,'macros.h']]],
  ['out_5fbuf',['OUT_BUF',['../macros_8h.html#acfb42dde389e8ca36ab267002fbf5c6a',1,'macros.h']]]
];
