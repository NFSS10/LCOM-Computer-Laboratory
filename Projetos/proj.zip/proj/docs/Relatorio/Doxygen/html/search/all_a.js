var searchData=
[
  ['j_5fx',['J_X',['../macros_8h.html#a2145674c8c97fe68eb45e125015265cf',1,'macros.h']]],
  ['j_5fy',['J_Y',['../macros_8h.html#a0c565c4e48cfb55968f6879534a13a49',1,'macros.h']]],
  ['jog_5fl',['JOG_L',['../macros_8h.html#aa2670689fc5cc3f317c60a7f9beeb11b',1,'macros.h']]],
  ['jog_5fmov',['JOG_MOV',['../macros_8h.html#a0b6c5acba936fb1be0fd7a13967df532',1,'macros.h']]],
  ['jogadora',['JogadorA',['../_graficos_8c.html#aaad7d64831457597b0bcfcedea45cda8',1,'Graficos.c']]],
  ['jogadorb',['JogadorB',['../_graficos_8c.html#ae1f6b7ad3428039600cf8f4db52eba9b',1,'Graficos.c']]],
  ['jogadorc',['JogadorC',['../_graficos_8c.html#a5c1261f928c54b30a6dc320fccd1153f',1,'Graficos.c']]],
  ['jogar',['jogar',['../_jogo_8c.html#a83740a43b8d51aa5ed3c37dafb95aa53',1,'jogar():&#160;Jogo.c'],['../_jogo_8h.html#a83740a43b8d51aa5ed3c37dafb95aa53',1,'jogar():&#160;Jogo.c']]],
  ['jogo_2ec',['Jogo.c',['../_jogo_8c.html',1,'']]],
  ['jogo_2eh',['Jogo.h',['../_jogo_8h.html',1,'']]]
];
