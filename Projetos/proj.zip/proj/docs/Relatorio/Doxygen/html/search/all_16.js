var searchData=
[
  ['v_5fres',['V_RES',['../macros_8h.html#aac2466862bcfc18231c38fe1eacc22e3',1,'macros.h']]],
  ['vbe',['vbe',['../group__vbe.html',1,'']]],
  ['vbe_2eh',['vbe.h',['../vbe_8h.html',1,'']]],
  ['vbe_5fget_5fmode_5finfo',['vbe_get_mode_info',['../group__vbe.html#ga4ef3234e41f2050bc094a22049b69e45',1,'vbe.h']]],
  ['vel_5fqueda',['VEL_QUEDA',['../macros_8h.html#ae1dc0d5204e1b61a7636148ee3535e96',1,'macros.h']]],
  ['video_5fexit',['video_exit',['../_graficos_8c.html#a3b4db62745bac4af50d9387e5847f3d0',1,'video_exit(void):&#160;Graficos.c'],['../_graficos_8h.html#a3b4db62745bac4af50d9387e5847f3d0',1,'video_exit(void):&#160;Graficos.c']]],
  ['video_5finit',['video_init',['../_graficos_8c.html#afc480f5434f2e67a76a16e9d5418dbec',1,'video_init(unsigned short mode):&#160;Graficos.c'],['../_graficos_8h.html#afc480f5434f2e67a76a16e9d5418dbec',1,'video_init(unsigned short mode):&#160;Graficos.c']]],
  ['vram_5fphys_5faddr',['VRAM_PHYS_ADDR',['../macros_8h.html#ac854e8352d97c69bdfe247573593ba3b',1,'macros.h']]]
];
