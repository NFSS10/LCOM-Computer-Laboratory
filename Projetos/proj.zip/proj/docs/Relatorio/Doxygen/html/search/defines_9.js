var searchData=
[
  ['makecode_5fi',['MAKECODE_I',['../macros_8h.html#af9fa7aef7acb8ecb5ba8158e60a465e7',1,'macros.h']]],
  ['mov_5fv',['MOV_V',['../macros_8h.html#a2d3baf7146d3641886541514b651a7da',1,'macros.h']]]
];
