var searchData=
[
  ['vbe_5fget_5fmode_5finfo',['vbe_get_mode_info',['../group__vbe.html#ga4ef3234e41f2050bc094a22049b69e45',1,'vbe.h']]],
  ['video_5fexit',['video_exit',['../_graficos_8c.html#a3b4db62745bac4af50d9387e5847f3d0',1,'video_exit(void):&#160;Graficos.c'],['../_graficos_8h.html#a3b4db62745bac4af50d9387e5847f3d0',1,'video_exit(void):&#160;Graficos.c']]],
  ['video_5finit',['video_init',['../_graficos_8c.html#afc480f5434f2e67a76a16e9d5418dbec',1,'video_init(unsigned short mode):&#160;Graficos.c'],['../_graficos_8h.html#afc480f5434f2e67a76a16e9d5418dbec',1,'video_init(unsigned short mode):&#160;Graficos.c']]]
];
