var searchData=
[
  ['limite_5fi',['LIMITE_I',['../macros_8h.html#a3fbf0d880e2ea56fc423740e96b54086',1,'macros.h']]],
  ['limite_5fs',['LIMITE_S',['../macros_8h.html#acacb44b76fc8004eb2aa945585f59fc3',1,'macros.h']]]
];
