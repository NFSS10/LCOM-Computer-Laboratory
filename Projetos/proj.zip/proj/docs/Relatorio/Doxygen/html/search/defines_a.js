var searchData=
[
  ['nack',['NACK',['../macros_8h.html#a958518a45b12053ae33606ee7cb68a55',1,'macros.h']]],
  ['nuvens_5fh',['NUVENS_H',['../macros_8h.html#a62cebbb69fcdd600b6addcae5035a844',1,'macros.h']]],
  ['nuvens_5fr',['NUVENS_R',['../macros_8h.html#a53dd16360aa515a39287a856aac61744',1,'macros.h']]],
  ['nuvens_5fvel',['NUVENS_VEL',['../macros_8h.html#a150ee204be9feeb85f371e1ce75e7aef',1,'macros.h']]]
];
