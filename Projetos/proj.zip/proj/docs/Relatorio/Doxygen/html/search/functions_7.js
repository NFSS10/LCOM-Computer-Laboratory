var searchData=
[
  ['jogar',['jogar',['../_jogo_8c.html#a83740a43b8d51aa5ed3c37dafb95aa53',1,'jogar():&#160;Jogo.c'],['../_jogo_8h.html#a83740a43b8d51aa5ed3c37dafb95aa53',1,'jogar():&#160;Jogo.c']]]
];
