var searchData=
[
  ['y',['y',['../struct_mouse.html#a0a2f84ed7838f07779ae24c5a9086d33',1,'Mouse::y()'],['../mouse_8h.html#add68d678c19efe50a109bda749b09c7a',1,'y():&#160;mouse.h']]],
  ['y_5fpixeis',['y_pixeis',['../struct_b_m_p___info___header.html#a2fa25e15fc69d1e92af7d1f60eced177',1,'BMP_Info_Header']]],
  ['ycharsize',['YCharSize',['../struct____attribute____.html#a330f00ebd49dccd2325d43cdbd646f09',1,'__attribute__']]],
  ['yresolution',['YResolution',['../struct____attribute____.html#afa8aba2156994750d500f85d0f8425cb',1,'__attribute__']]]
];
