var searchData=
[
  ['updatemouse',['updateMouse',['../mouse_8c.html#a8e7912f46f949e7c345e4dd16fdff551',1,'updateMouse(long int *packet_info, Mouse *m):&#160;mouse.c'],['../mouse_8h.html#a8e7912f46f949e7c345e4dd16fdff551',1,'updateMouse(long int *packet_info, Mouse *m):&#160;mouse.c']]]
];
