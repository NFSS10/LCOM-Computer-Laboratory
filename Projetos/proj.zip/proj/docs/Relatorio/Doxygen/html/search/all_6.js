var searchData=
[
  ['fazjogada',['fazjogada',['../_jogo_8c.html#ad253de5cc767d2c1370e79286b25f046',1,'fazjogada(unsigned int tamanho, unsigned int x_ale, unsigned int plat_ale, unsigned int N_plat_Antiga):&#160;Jogo.c'],['../_jogo_8h.html#ad253de5cc767d2c1370e79286b25f046',1,'fazjogada(unsigned int tamanho, unsigned int x_ale, unsigned int plat_ale, unsigned int N_plat_Antiga):&#160;Jogo.c']]]
];
