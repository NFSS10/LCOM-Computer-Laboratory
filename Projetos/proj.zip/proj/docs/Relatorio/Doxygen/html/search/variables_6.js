var searchData=
[
  ['jogadora',['JogadorA',['../_graficos_8c.html#aaad7d64831457597b0bcfcedea45cda8',1,'Graficos.c']]],
  ['jogadorb',['JogadorB',['../_graficos_8c.html#ae1f6b7ad3428039600cf8f4db52eba9b',1,'Graficos.c']]],
  ['jogadorc',['JogadorC',['../_graficos_8c.html#a5c1261f928c54b30a6dc320fccd1153f',1,'Graficos.c']]]
];
