var searchData=
[
  ['x',['x',['../struct_mouse.html#a6150e0515f7202e2fb518f7206ed97dc',1,'Mouse::x()'],['../mouse_8h.html#aefaad1a055682b77784fb2536b9a986b',1,'x():&#160;mouse.h']]],
  ['x_5fpixeis',['x_pixeis',['../struct_b_m_p___info___header.html#af2708a99f34daaf4fc7ba3fff2e3da71',1,'BMP_Info_Header']]],
  ['xcharsize',['XCharSize',['../struct____attribute____.html#a047d8f41434f02589d0c9b90b17c67eb',1,'__attribute__']]],
  ['xresolution',['XResolution',['../struct____attribute____.html#a16f6408e5a85c7a7785a0cee64b6a219',1,'__attribute__']]]
];
