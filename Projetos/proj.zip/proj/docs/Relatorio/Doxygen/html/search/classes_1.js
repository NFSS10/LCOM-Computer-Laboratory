var searchData=
[
  ['bmp_5ffile_5fheader',['BMP_File_Header',['../struct_b_m_p___file___header.html',1,'']]],
  ['bmp_5finfo_5fheader',['BMP_Info_Header',['../struct_b_m_p___info___header.html',1,'']]]
];
