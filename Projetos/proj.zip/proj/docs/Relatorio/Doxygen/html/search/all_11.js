var searchData=
[
  ['quedajogador',['quedaJogador',['../_graficos_8c.html#ab257d0373f294826e5066385a615afe6',1,'quedaJogador(unsigned int posicao, unsigned int x_ale, unsigned int plat_ale, unsigned int n_plat_antiga, int Pontos):&#160;Graficos.c'],['../_graficos_8h.html#ab257d0373f294826e5066385a615afe6',1,'quedaJogador(unsigned int posicao, unsigned int x_ale, unsigned int plat_ale, unsigned int n_plat_antiga, int Pontos):&#160;Graficos.c']]]
];
