var searchData=
[
  ['p_5fmov_5fantiga',['P_MOV_ANTIGA',['../macros_8h.html#a0af44f162a3c2f57be4f9d3845510bb2',1,'macros.h']]],
  ['p_5fmov_5fnova',['P_MOV_NOVA',['../macros_8h.html#afaa8a62f0575f2c6e901e39e4e5d869a',1,'macros.h']]],
  ['p_5fx',['P_X',['../macros_8h.html#abd656aa126020ef16064e445a9ed8653',1,'macros.h']]],
  ['p_5fy',['P_Y',['../macros_8h.html#ab967c15330f7aad8d428fb039d5b9b4a',1,'macros.h']]],
  ['parity',['PARITY',['../macros_8h.html#af6996d12e71a534569c41a25de7d6d52',1,'macros.h']]],
  ['plat0',['PLAT0',['../macros_8h.html#ac024a1ca3a80db1d685a8c369c465b15',1,'macros.h']]],
  ['plat1',['PLAT1',['../macros_8h.html#a5502de5b80299bee119e1eea9a4f5321',1,'macros.h']]],
  ['plat2',['PLAT2',['../macros_8h.html#a2589aeccd4cc992c15d55cc7c6de44e3',1,'macros.h']]],
  ['plat3',['PLAT3',['../macros_8h.html#aa79cd66cb3deaa103a5a0c3f8193dbb4',1,'macros.h']]],
  ['plat4',['PLAT4',['../macros_8h.html#aa4dccd281e6f1eba2cd231ec54ea7984',1,'macros.h']]],
  ['plat5',['PLAT5',['../macros_8h.html#a7bcef688fe368778f25b43a3827a0f04',1,'macros.h']]],
  ['plat6',['PLAT6',['../macros_8h.html#a2ac9f972fdc5be9a692a812e6c403521',1,'macros.h']]],
  ['plat7',['PLAT7',['../macros_8h.html#a262d5dd1da5a110f0c3b61785a604429',1,'macros.h']]],
  ['plat8',['PLAT8',['../macros_8h.html#a1eda799b537de54a436189b4dbf60533',1,'macros.h']]]
];
