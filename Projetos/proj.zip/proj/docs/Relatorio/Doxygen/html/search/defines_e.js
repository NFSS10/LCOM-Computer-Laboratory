var searchData=
[
  ['sensibilidade_5fbarra',['SENSIBILIDADE_BARRA',['../macros_8h.html#a5a9dd96334cc513baee6acda5aefdc92',1,'macros.h']]],
  ['set_5fres',['SET_RES',['../macros_8h.html#aac7cc6ae1526808cb70bc95de2d9e348',1,'macros.h']]],
  ['set_5fsample_5frate',['SET_SAMPLE_RATE',['../macros_8h.html#a7f57224ffb2b6d5adfc1e4cb0118c7f9',1,'macros.h']]],
  ['set_5fsca1',['SET_SCA1',['../macros_8h.html#acb17a9d9f071259465e4694046f745e8',1,'macros.h']]],
  ['set_5fsca2',['SET_SCA2',['../macros_8h.html#ae8c53072e3ad8f5b67607fdf342b8095',1,'macros.h']]],
  ['set_5fstream_5fmode',['SET_STREAM_MODE',['../macros_8h.html#aabf49b4a4d8ad72d202c8a7197058e35',1,'macros.h']]],
  ['stat_5freg',['STAT_REG',['../macros_8h.html#a89c4d098b53809674457b1660b1af780',1,'macros.h']]],
  ['status_5freq',['STATUS_REQ',['../macros_8h.html#ade04d2b8ffc909668670d9bc0f01aa93',1,'macros.h']]]
];
