var searchData=
[
  ['newmenu',['newMenu',['../_menu_8c.html#ab4c4331657aad73fe461b1946d6a80e6',1,'newMenu():&#160;Menu.c'],['../_menu_8h.html#ab4c4331657aad73fe461b1946d6a80e6',1,'newMenu():&#160;Menu.c']]],
  ['newmenufinal',['newMenuFinal',['../menufinal_8c.html#ab10d37f563e05dbdd7bb6983c42c4ee7',1,'newMenuFinal(int score):&#160;menufinal.c'],['../menufinal_8h.html#ab10d37f563e05dbdd7bb6983c42c4ee7',1,'newMenuFinal(int score):&#160;menufinal.c']]],
  ['newmouse',['newMouse',['../mouse_8c.html#abd64fd476265e0fb0463cc3d82823701',1,'newMouse():&#160;mouse.c'],['../mouse_8h.html#abd64fd476265e0fb0463cc3d82823701',1,'newMouse():&#160;mouse.c']]]
];
