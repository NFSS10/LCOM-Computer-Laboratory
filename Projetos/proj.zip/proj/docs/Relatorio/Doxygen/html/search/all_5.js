var searchData=
[
  ['en_5fsend_5fdata',['EN_SEND_DATA',['../macros_8h.html#a7f822112215ede36a597535518d6d1a4',1,'macros.h']]],
  ['endgame',['endGame',['../_utilidades_8c.html#aeaf240695219ca5a84db74cfee54736e',1,'endGame():&#160;Utilidades.c'],['../_utilidades_8h.html#aeaf240695219ca5a84db74cfee54736e',1,'endGame():&#160;Utilidades.c']]],
  ['endmenu',['endMenu',['../menufinal_8c.html#a5e0efe95b4d3278c751077264fabd87c',1,'endMenu(MenuFinal *m):&#160;menufinal.c'],['../menufinal_8h.html#a5e0efe95b4d3278c751077264fabd87c',1,'endMenu(MenuFinal *m):&#160;menufinal.c']]],
  ['enter',['ENTER',['../macros_8h.html#af4bced5cf8ed55746d4b5d34f9a0fe39',1,'macros.h']]],
  ['error',['ERROR',['../macros_8h.html#a8fe83ac76edc595f6b98cd4a4127aed5',1,'macros.h']]],
  ['erva_5fh',['ERVA_H',['../macros_8h.html#a8bf2f9a83d47c9929a05f72a72316c2f',1,'macros.h']]],
  ['erva_5fr',['ERVA_R',['../macros_8h.html#a8192c18ce5a79932fcf89b3132672f75',1,'macros.h']]],
  ['erva_5fvel',['ERVA_VEL',['../macros_8h.html#a4afe89c06c3d79c6ee13b422d68a5e63',1,'macros.h']]],
  ['ervas',['Ervas',['../_graficos_8c.html#a078d595fd442582ab98104aa9efd9f13',1,'Graficos.c']]],
  ['escolheplataforma',['escolhePlataforma',['../_graficos_8c.html#a13aed592aba8b9b736d98dcf875abd67',1,'escolhePlataforma(unsigned int n):&#160;Graficos.c'],['../_graficos_8h.html#a13aed592aba8b9b736d98dcf875abd67',1,'escolhePlataforma(unsigned int n):&#160;Graficos.c']]],
  ['espaco',['ESPACO',['../macros_8h.html#a4453988a58038ca57db65b161fee8a3a',1,'macros.h']]],
  ['espaco_5fr',['ESPACO_R',['../macros_8h.html#ad4902da783b720e889936e38d6deb199',1,'macros.h']]]
];
