var searchData=
[
  ['endgame',['endGame',['../_utilidades_8c.html#aeaf240695219ca5a84db74cfee54736e',1,'endGame():&#160;Utilidades.c'],['../_utilidades_8h.html#aeaf240695219ca5a84db74cfee54736e',1,'endGame():&#160;Utilidades.c']]],
  ['endmenu',['endMenu',['../menufinal_8c.html#a5e0efe95b4d3278c751077264fabd87c',1,'endMenu(MenuFinal *m):&#160;menufinal.c'],['../menufinal_8h.html#a5e0efe95b4d3278c751077264fabd87c',1,'endMenu(MenuFinal *m):&#160;menufinal.c']]],
  ['escolheplataforma',['escolhePlataforma',['../_graficos_8c.html#a13aed592aba8b9b736d98dcf875abd67',1,'escolhePlataforma(unsigned int n):&#160;Graficos.c'],['../_graficos_8h.html#a13aed592aba8b9b736d98dcf875abd67',1,'escolhePlataforma(unsigned int n):&#160;Graficos.c']]]
];
