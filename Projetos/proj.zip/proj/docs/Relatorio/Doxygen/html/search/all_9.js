var searchData=
[
  ['ibf',['IBF',['../macros_8h.html#a3c48b10907056351582baf9f6478598e',1,'macros.h']]],
  ['imagem',['Imagem',['../struct_imagem.html',1,'']]],
  ['in_5fbuf',['IN_BUF',['../macros_8h.html#a783be5698cf07b1daaf126ef89c19063',1,'macros.h']]],
  ['inicializaimagens',['inicializaimagens',['../_graficos_8c.html#a2979447069f40e3819db034e81b67ebf',1,'inicializaimagens():&#160;Graficos.c'],['../_graficos_8h.html#a2979447069f40e3819db034e81b67ebf',1,'inicializaimagens():&#160;Graficos.c']]],
  ['irq_5fmouse',['IRQ_MOUSE',['../macros_8h.html#a32ffe73ffc337fbec467ea02948591af',1,'macros.h']]],
  ['irq_5frtc',['IRQ_RTC',['../macros_8h.html#a910ac5f2c1b4016e433f9832358a1816',1,'macros.h']]]
];
