var searchData=
[
  ['data',['Data',['../struct_imagem.html#a73e3fe296fd3f764e4a9b864cee23353',1,'Imagem']]],
  ['directcolormodeinfo',['DirectColorModeInfo',['../struct____attribute____.html#a3bf2fd2394ec8649ec3d26104be35dd7',1,'__attribute__']]]
];
