var searchData=
[
  ['ibf',['IBF',['../macros_8h.html#a3c48b10907056351582baf9f6478598e',1,'macros.h']]],
  ['in_5fbuf',['IN_BUF',['../macros_8h.html#a783be5698cf07b1daaf126ef89c19063',1,'macros.h']]],
  ['irq_5fmouse',['IRQ_MOUSE',['../macros_8h.html#a32ffe73ffc337fbec467ea02948591af',1,'macros.h']]],
  ['irq_5frtc',['IRQ_RTC',['../macros_8h.html#a910ac5f2c1b4016e433f9832358a1816',1,'macros.h']]]
];
