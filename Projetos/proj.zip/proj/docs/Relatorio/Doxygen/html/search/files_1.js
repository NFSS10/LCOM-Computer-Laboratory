var searchData=
[
  ['graficos_2ec',['Graficos.c',['../_graficos_8c.html',1,'']]],
  ['graficos_2eh',['Graficos.h',['../_graficos_8h.html',1,'']]]
];
