var searchData=
[
  ['j_5fx',['J_X',['../macros_8h.html#a2145674c8c97fe68eb45e125015265cf',1,'macros.h']]],
  ['j_5fy',['J_Y',['../macros_8h.html#a0c565c4e48cfb55968f6879534a13a49',1,'macros.h']]],
  ['jog_5fl',['JOG_L',['../macros_8h.html#aa2670689fc5cc3f317c60a7f9beeb11b',1,'macros.h']]],
  ['jog_5fmov',['JOG_MOV',['../macros_8h.html#a0b6c5acba936fb1be0fd7a13967df532',1,'macros.h']]]
];
