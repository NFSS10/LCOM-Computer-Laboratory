var searchData=
[
  ['rtc_5fsubscribe_5fint',['rtc_subscribe_int',['../_r_t_c_8c.html#a6bd13bd1e0cd043f50abb97bcc138bfa',1,'rtc_subscribe_int(void):&#160;RTC.c'],['../_r_t_c_8h.html#a6bd13bd1e0cd043f50abb97bcc138bfa',1,'rtc_subscribe_int(void):&#160;RTC.c']]],
  ['rtc_5funsubscribe_5fint',['rtc_unsubscribe_int',['../_r_t_c_8c.html#ab8f17bf5280c908c8b199a90fefcc758',1,'rtc_unsubscribe_int():&#160;RTC.c'],['../_r_t_c_8h.html#ab8f17bf5280c908c8b199a90fefcc758',1,'rtc_unsubscribe_int():&#160;RTC.c']]],
  ['rtc_5fwrite_5fbcd_5fto_5fbinary',['rtc_write_bcd_to_binary',['../_r_t_c_8c.html#afac093c61f42bba4a96a1643223fdb7f',1,'rtc_write_bcd_to_binary(void):&#160;RTC.c'],['../_r_t_c_8h.html#a597e26b541a78e4e77aa941d6b181ed1',1,'rtc_write_bcd_to_binary():&#160;RTC.c']]]
];
