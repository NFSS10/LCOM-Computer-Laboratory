var searchData=
[
  ['larg',['larg',['../_jogo_8c.html#aadd0b777de4ff70672b7bbc504f27293',1,'larg(unsigned int n):&#160;Jogo.c'],['../_jogo_8h.html#aadd0b777de4ff70672b7bbc504f27293',1,'larg(unsigned int n):&#160;Jogo.c']]],
  ['loadbitmapfile',['LoadBitmapFile',['../_b_m_p_8c.html#a649f4d3b624f59439cea2a698681bdf2',1,'LoadBitmapFile(const char *nome_ficheiro):&#160;BMP.c'],['../_b_m_p_8h.html#a77232688c26c93fecc8e7c44e0b50f35',1,'LoadBitmapFile(const char *filename):&#160;BMP.c']]],
  ['loadscore',['loadScore',['../_utilidades_8c.html#a16e7461f92ed135964e507d14f8aecd4',1,'loadScore():&#160;Utilidades.c'],['../_utilidades_8h.html#a16e7461f92ed135964e507d14f8aecd4',1,'loadScore():&#160;Utilidades.c']]]
];
