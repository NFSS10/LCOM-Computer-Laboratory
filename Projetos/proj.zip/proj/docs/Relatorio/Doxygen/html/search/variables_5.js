var searchData=
[
  ['greenfieldposition',['GreenFieldPosition',['../struct____attribute____.html#a602b28f8e5da781eabfd736743a6ea09',1,'__attribute__']]],
  ['greenmasksize',['GreenMaskSize',['../struct____attribute____.html#ac7b4df72e505b74493e7d5144cbac743',1,'__attribute__']]]
];
