var searchData=
[
  ['v_5fres',['V_RES',['../macros_8h.html#aac2466862bcfc18231c38fe1eacc22e3',1,'macros.h']]],
  ['vel_5fqueda',['VEL_QUEDA',['../macros_8h.html#ae1dc0d5204e1b61a7636148ee3535e96',1,'macros.h']]],
  ['vram_5fphys_5faddr',['VRAM_PHYS_ADDR',['../macros_8h.html#ac854e8352d97c69bdfe247573593ba3b',1,'macros.h']]]
];
