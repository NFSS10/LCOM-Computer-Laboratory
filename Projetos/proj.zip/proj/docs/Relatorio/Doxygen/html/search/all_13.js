var searchData=
[
  ['savescore',['saveScore',['../_utilidades_8c.html#aa8794a9f998f0c7c40ab732ba7bf0a81',1,'saveScore(unsigned int score):&#160;Utilidades.c'],['../_utilidades_8h.html#aa8794a9f998f0c7c40ab732ba7bf0a81',1,'saveScore(unsigned int score):&#160;Utilidades.c']]],
  ['score',['score',['../struct_menu_final.html#aef160b7437d94056f1dc59646cd5b87d',1,'MenuFinal']]],
  ['sensibilidade_5fbarra',['SENSIBILIDADE_BARRA',['../macros_8h.html#a5a9dd96334cc513baee6acda5aefdc92',1,'macros.h']]],
  ['set_5fres',['SET_RES',['../macros_8h.html#aac7cc6ae1526808cb70bc95de2d9e348',1,'macros.h']]],
  ['set_5fsample_5frate',['SET_SAMPLE_RATE',['../macros_8h.html#a7f57224ffb2b6d5adfc1e4cb0118c7f9',1,'macros.h']]],
  ['set_5fsca1',['SET_SCA1',['../macros_8h.html#acb17a9d9f071259465e4694046f745e8',1,'macros.h']]],
  ['set_5fsca2',['SET_SCA2',['../macros_8h.html#ae8c53072e3ad8f5b67607fdf342b8095',1,'macros.h']]],
  ['set_5fstream_5fmode',['SET_STREAM_MODE',['../macros_8h.html#aabf49b4a4d8ad72d202c8a7197058e35',1,'macros.h']]],
  ['show_5fstatus',['show_status',['../mouse_8c.html#ae98d7fe78d70a6b901877f90cea8f901',1,'show_status(long int *packet_info):&#160;mouse.c'],['../mouse_8h.html#ae98d7fe78d70a6b901877f90cea8f901',1,'show_status(long int *packet_info):&#160;mouse.c']]],
  ['showclock',['showClock',['../_menu_8c.html#a952c49d90a56ae3b54aa3163e03ff065',1,'showClock(Menu *m):&#160;Menu.c'],['../_menu_8h.html#a952c49d90a56ae3b54aa3163e03ff065',1,'showClock(Menu *m):&#160;Menu.c']]],
  ['sprite',['sprite',['../struct_menu.html#a2975f8ea8b9abb6e37dfa93be87dbff3',1,'Menu::sprite()'],['../struct_menu_final.html#a2975f8ea8b9abb6e37dfa93be87dbff3',1,'MenuFinal::sprite()'],['../struct_mouse.html#a2975f8ea8b9abb6e37dfa93be87dbff3',1,'Mouse::sprite()']]],
  ['sprite2',['sprite2',['../struct_menu.html#a4b74855fae6d0e049bfe20b4e986fe54',1,'Menu']]],
  ['sprite3',['sprite3',['../struct_menu.html#a04ec0ecb8a455864a18ea19454221e3c',1,'Menu']]],
  ['startgame',['startGame',['../_utilidades_8c.html#adb5df83e344af02ebe373911683bbd36',1,'startGame():&#160;Utilidades.c'],['../_utilidades_8h.html#adb5df83e344af02ebe373911683bbd36',1,'startGame():&#160;Utilidades.c']]],
  ['stat_5freg',['STAT_REG',['../macros_8h.html#a89c4d098b53809674457b1660b1af780',1,'macros.h']]],
  ['stateofgame',['stateOfGame',['../struct_menu.html#a222be307e1ea01b6fceef22824681e25',1,'Menu']]],
  ['status_5freq',['STATUS_REQ',['../macros_8h.html#ade04d2b8ffc909668670d9bc0f01aa93',1,'macros.h']]]
];
