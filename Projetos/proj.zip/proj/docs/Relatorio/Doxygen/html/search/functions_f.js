var searchData=
[
  ['savescore',['saveScore',['../_utilidades_8c.html#aa8794a9f998f0c7c40ab732ba7bf0a81',1,'saveScore(unsigned int score):&#160;Utilidades.c'],['../_utilidades_8h.html#aa8794a9f998f0c7c40ab732ba7bf0a81',1,'saveScore(unsigned int score):&#160;Utilidades.c']]],
  ['show_5fstatus',['show_status',['../mouse_8c.html#ae98d7fe78d70a6b901877f90cea8f901',1,'show_status(long int *packet_info):&#160;mouse.c'],['../mouse_8h.html#ae98d7fe78d70a6b901877f90cea8f901',1,'show_status(long int *packet_info):&#160;mouse.c']]],
  ['showclock',['showClock',['../_menu_8c.html#a952c49d90a56ae3b54aa3163e03ff065',1,'showClock(Menu *m):&#160;Menu.c'],['../_menu_8h.html#a952c49d90a56ae3b54aa3163e03ff065',1,'showClock(Menu *m):&#160;Menu.c']]],
  ['startgame',['startGame',['../_utilidades_8c.html#adb5df83e344af02ebe373911683bbd36',1,'startGame():&#160;Utilidades.c'],['../_utilidades_8h.html#adb5df83e344af02ebe373911683bbd36',1,'startGame():&#160;Utilidades.c']]]
];
