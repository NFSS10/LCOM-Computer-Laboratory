var searchData=
[
  ['barra_5fx_5fi',['BARRA_X_I',['../macros_8h.html#ae75f9b8ce448708cddcbd12664fe8626',1,'macros.h']]],
  ['barra_5fy_5fi',['BARRA_Y_I',['../macros_8h.html#af5e547d2279a4eeca8c4ed7bff708579',1,'macros.h']]],
  ['bit',['BIT',['../macros_8h.html#a3a8ea58898cb58fc96013383d39f482c',1,'macros.h']]],
  ['bits_5fper_5fpixel',['BITS_PER_PIXEL',['../macros_8h.html#a35faf89171af20cd21088c37d62bb7ee',1,'macros.h']]],
  ['bmp_5fassinatura',['BMP_ASSINATURA',['../macros_8h.html#a8cfd18cd49eaaba1f8ca577ed4c30003',1,'macros.h']]],
  ['breakcode_5fi',['BREAKCODE_I',['../macros_8h.html#a6900e70c85810fec5a0a349eae193c8c',1,'macros.h']]],
  ['bytes_5fper_5fpixel',['BYTES_PER_PIXEL',['../macros_8h.html#ae138b2e443649ca9546c99e80957faac',1,'macros.h']]]
];
