var searchData=
[
  ['redfieldposition',['RedFieldPosition',['../struct____attribute____.html#a20cb142b8c1b0a2b41244fef469a11f4',1,'__attribute__']]],
  ['redmasksize',['RedMaskSize',['../struct____attribute____.html#a5e25f6a8eedde631fff577bcf7d4f6f4',1,'__attribute__']]],
  ['reservado',['reservado',['../struct_b_m_p___file___header.html#af6c47561aae0769d732293d4fbe752f0',1,'BMP_File_Header']]],
  ['reserved1',['Reserved1',['../struct____attribute____.html#a604037992fe7e5fd08e1bcc684a1b12d',1,'__attribute__']]],
  ['reserved2',['Reserved2',['../struct____attribute____.html#a09b5824ec5c67bee2a4b36c0ab5181bc',1,'__attribute__']]],
  ['reserved3',['Reserved3',['../struct____attribute____.html#a2455a82e0d8cc0e8d76e8cf77a68bd39',1,'__attribute__']]],
  ['reserved4',['Reserved4',['../struct____attribute____.html#a2e13c4795a00241b919aa3aab86560ce',1,'__attribute__']]],
  ['rsvdfieldposition',['RsvdFieldPosition',['../struct____attribute____.html#aa357b085181776f2918a6df25c88846b',1,'__attribute__']]],
  ['rsvdmasksize',['RsvdMaskSize',['../struct____attribute____.html#a87d544680f1132f30b038c0ebf0b829b',1,'__attribute__']]]
];
