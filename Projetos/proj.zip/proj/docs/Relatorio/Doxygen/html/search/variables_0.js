var searchData=
[
  ['altura',['altura',['../struct_b_m_p___info___header.html#a5d64327d171befff73b176998204a4e9',1,'BMP_Info_Header']]],
  ['assinatura',['assinatura',['../struct_b_m_p___file___header.html#a019a0e740de3d4ca6ad45bbec7dc5104',1,'BMP_File_Header']]]
];
