var searchData=
[
  ['ack',['ACK',['../macros_8h.html#a6f6489887e08bff4887d0bc5dcf214d8',1,'macros.h']]]
];
