var searchData=
[
  ['compressao',['compressao',['../struct_b_m_p___info___header.html#a7400a3653d4286bb61b44c09782e2985',1,'BMP_Info_Header']]]
];
