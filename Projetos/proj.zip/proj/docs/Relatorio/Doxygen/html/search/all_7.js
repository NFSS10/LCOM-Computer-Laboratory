var searchData=
[
  ['graficos_2ec',['Graficos.c',['../_graficos_8c.html',1,'']]],
  ['graficos_2eh',['Graficos.h',['../_graficos_8h.html',1,'']]],
  ['greenfieldposition',['GreenFieldPosition',['../struct____attribute____.html#a602b28f8e5da781eabfd736743a6ea09',1,'__attribute__']]],
  ['greenmasksize',['GreenMaskSize',['../struct____attribute____.html#ac7b4df72e505b74493e7d5144cbac743',1,'__attribute__']]]
];
