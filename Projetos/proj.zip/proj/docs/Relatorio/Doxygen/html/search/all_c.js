var searchData=
[
  ['larg',['larg',['../_jogo_8c.html#aadd0b777de4ff70672b7bbc504f27293',1,'larg(unsigned int n):&#160;Jogo.c'],['../_jogo_8h.html#aadd0b777de4ff70672b7bbc504f27293',1,'larg(unsigned int n):&#160;Jogo.c']]],
  ['largura',['largura',['../struct_b_m_p___info___header.html#ade17a28dd3b4319f5227521085bc5243',1,'BMP_Info_Header']]],
  ['leftclick',['leftClick',['../struct_mouse.html#a17690036d8ec5bbf75bc074b8485fee2',1,'Mouse']]],
  ['limite_5fi',['LIMITE_I',['../macros_8h.html#a3fbf0d880e2ea56fc423740e96b54086',1,'macros.h']]],
  ['limite_5fs',['LIMITE_S',['../macros_8h.html#acacb44b76fc8004eb2aa945585f59fc3',1,'macros.h']]],
  ['linbluefieldposition',['LinBlueFieldPosition',['../struct____attribute____.html#a3f38d6becbe961786cd7ab58ec37fc07',1,'__attribute__']]],
  ['linbluemasksize',['LinBlueMaskSize',['../struct____attribute____.html#ad8a25cec803bf91fb40a20a0aa5d5bf7',1,'__attribute__']]],
  ['linbytesperscanline',['LinBytesPerScanLine',['../struct____attribute____.html#a53c5060b6ac14a7418ca8421edfb9981',1,'__attribute__']]],
  ['lingreenfieldposition',['LinGreenFieldPosition',['../struct____attribute____.html#a6683a63711dbc5dfb9a2a59c55deecd5',1,'__attribute__']]],
  ['lingreenmasksize',['LinGreenMaskSize',['../struct____attribute____.html#af235e505028771ab2fb84778f4dfb476',1,'__attribute__']]],
  ['linnumberofimagepages',['LinNumberOfImagePages',['../struct____attribute____.html#a3fa2352e69836f4b69b3a344ae761ba8',1,'__attribute__']]],
  ['linredfieldposition',['LinRedFieldPosition',['../struct____attribute____.html#aff962b58f86a77f12b412d47125a4993',1,'__attribute__']]],
  ['linredmasksize',['LinRedMaskSize',['../struct____attribute____.html#a1fbcef2402fe6ce7f6c006bd50eaa6da',1,'__attribute__']]],
  ['linrsvdfieldposition',['LinRsvdFieldPosition',['../struct____attribute____.html#a3df070e698b5f54814e20c8813f7bf7e',1,'__attribute__']]],
  ['linrsvdmasksize',['LinRsvdMaskSize',['../struct____attribute____.html#a334886fc9a915ff91966c3aac1da586a',1,'__attribute__']]],
  ['loadbitmapfile',['LoadBitmapFile',['../_b_m_p_8c.html#a649f4d3b624f59439cea2a698681bdf2',1,'LoadBitmapFile(const char *nome_ficheiro):&#160;BMP.c'],['../_b_m_p_8h.html#a77232688c26c93fecc8e7c44e0b50f35',1,'LoadBitmapFile(const char *filename):&#160;BMP.c']]],
  ['loadscore',['loadScore',['../_utilidades_8c.html#a16e7461f92ed135964e507d14f8aecd4',1,'loadScore():&#160;Utilidades.c'],['../_utilidades_8h.html#a16e7461f92ed135964e507d14f8aecd4',1,'loadScore():&#160;Utilidades.c']]],
  ['long',['LONG',['../_b_m_p_8h.html#a9154c0d0c21af4686624543215b4e5f2',1,'BMP.h']]]
];
