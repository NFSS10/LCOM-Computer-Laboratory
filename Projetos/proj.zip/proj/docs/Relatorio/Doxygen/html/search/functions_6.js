var searchData=
[
  ['inicializaimagens',['inicializaimagens',['../_graficos_8c.html#a2979447069f40e3819db034e81b67ebf',1,'inicializaimagens():&#160;Graficos.c'],['../_graficos_8h.html#a2979447069f40e3819db034e81b67ebf',1,'inicializaimagens():&#160;Graficos.c']]]
];
