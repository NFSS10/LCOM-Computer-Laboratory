service run `pwd`/StickHero
