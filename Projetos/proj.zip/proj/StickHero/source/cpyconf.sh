cp /home/lcom/lcom1516-t6g10/proj/StickHero/conf/StickHero /etc/system.conf.d
